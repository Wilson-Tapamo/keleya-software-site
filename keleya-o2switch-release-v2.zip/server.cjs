const path = require("node:path");

async function start() {
  const { startProdServer } = await import("vinext/server/prod-server");
  const port = Number.parseInt(process.env.PORT || "3000", 10);

  await startProdServer({
    port,
    host: "0.0.0.0",
    outDir: path.join(__dirname, "dist"),
  });
}

start().catch((error) => {
  console.error("Failed to start the Keleya production server:", error);
  process.exitCode = 1;
});
