export default {
  "bootstrapScriptContent": "import(\"/assets/index-CY4k_n5_.js\")",
  "clientReferenceDeps": {
    "9174d106898b": {
      "js": [
        "/assets/SiteShell-CTr6s2KT.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/Icon-C6gSHICf.js",
        "/assets/framework-CXnKph_e.js",
        "/assets/index-CY4k_n5_.js"
      ],
      "css": []
    },
    "4e07333fa9b7": {
      "js": [
        "/assets/page-DMxzzwg1.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/SiteShell-CTr6s2KT.js",
        "/assets/Icon-C6gSHICf.js",
        "/assets/framework-CXnKph_e.js",
        "/assets/index-CY4k_n5_.js"
      ],
      "css": []
    },
    "6efdf509a785": {
      "js": [
        "/assets/page-BbvZoOY0.js",
        "/assets/SiteShell-CTr6s2KT.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/Icon-C6gSHICf.js",
        "/assets/framework-CXnKph_e.js",
        "/assets/index-CY4k_n5_.js"
      ],
      "css": []
    },
    "339f946bc456": {
      "js": [
        "/assets/Icon-C6gSHICf.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-CXnKph_e.js",
        "/assets/index-CY4k_n5_.js"
      ],
      "css": []
    },
    "593f344dc510": {
      "js": [
        "/assets/index-CY4k_n5_.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-CXnKph_e.js"
      ],
      "css": []
    },
    "15c18cfaeeff": {
      "js": [
        "/assets/layout-segment-context-Bj7ydJBO.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/index-CY4k_n5_.js",
        "/assets/framework-CXnKph_e.js"
      ],
      "css": []
    },
    "8c0f216c4604": {
      "js": [
        "/assets/index-CY4k_n5_.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-CXnKph_e.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/assets/index-DyiCXDT5.css"
      ]
    }
  }
}