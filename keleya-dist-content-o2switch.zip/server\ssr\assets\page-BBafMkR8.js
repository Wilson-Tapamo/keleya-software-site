import { a as require_react, s as __toESM, t as require_jsx_runtime } from "../index.js";
import { PageHero, PageShell, n as createLucideIcon, t as ArrowUpRight } from "./SiteShell-Cow8zbxb.js";
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var CircleCheck = createLucideIcon("circle-check", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}], ["path", {
	d: "m9 12 2 2 4-4",
	key: "dzmm74"
}]]);
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Clock3 = createLucideIcon("clock-3", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}], ["path", {
	d: "M12 6v6h4",
	key: "135r8i"
}]]);
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Mail = createLucideIcon("mail", [["path", {
	d: "m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",
	key: "132q7q"
}], ["rect", {
	x: "2",
	y: "4",
	width: "20",
	height: "16",
	rx: "2",
	key: "izxlao"
}]]);
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var MapPin = createLucideIcon("map-pin", [["path", {
	d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
	key: "1r0f0z"
}], ["circle", {
	cx: "12",
	cy: "10",
	r: "3",
	key: "ilqhr7"
}]]);
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Phone = createLucideIcon("phone", [["path", {
	d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
	key: "9njp5v"
}]]);
//#endregion
//#region app/contact/page.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var options = [
	"Application web",
	"Application mobile",
	"Outil métier",
	"Design UI/UX",
	"Automatisation & IA",
	"Conseil / cadrage",
	"Autre"
];
var faqs = [
	["Quel est le délai habituel pour un projet ?", "La durée dépend de l’ambition et du périmètre. Après un premier échange, nous vous proposons des étapes claires, un calendrier réaliste et un premier résultat utile aussi tôt que possible."],
	["Travaillez-vous avec des clients hors du Cameroun ?", "Oui. Notre organisation est pensée pour collaborer efficacement à distance, en Afrique comme à l’international."],
	["Pouvez-vous reprendre un projet existant ?", "Oui. Nous commençons par un diagnostic simple de l’existant, puis recommandons ce qu’il faut conserver, améliorer ou repenser."],
	["Assurez-vous le suivi après le lancement ?", "Oui. Nous pouvons accompagner la prise en main, suivre les performances, corriger les points de friction et faire évoluer la solution."]
];
function ContactPage() {
	const [selected, setSelected] = (0, import_react.useState)([]);
	const [sent, setSent] = (0, import_react.useState)(false);
	const toggle = (item) => setSelected((items) => items.includes(item) ? items.filter((x) => x !== item) : [...items, item]);
	const submit = (event) => {
		event.preventDefault();
		setSent(true);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		current: "/contact",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			id: "contenu",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
					index: "04",
					kicker: "Nous contacter",
					title: "Vous avez une ambition ?",
					accent: "Donnons-lui de l’élan.",
					copy: "Racontez-nous ce que vous souhaitez changer. Nous vous répondons avec des questions utiles, des idées claires et une prochaine étape concrète."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "contact-zone light-section",
					id: "form",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "contact-info",
						"data-reveal": true,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Commençons simplement"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { children: [
								"Parlons de votre",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "prochain mouvement." })
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Quelques lignes suffisent. Aucun jargon nécessaire : dites-nous ce qui vous ralentit aujourd’hui et ce que vous aimeriez rendre possible demain." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "contact-details",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "mailto:hello@keleya.agency",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {}),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "E-MAIL" }), "hello@keleya.agency"] })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "tel:+237600000000",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {}),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "TÉLÉPHONE" }), "+237 600 000 000"] })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {}),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "LOCALISATION" }), "Yaoundé, Cameroun"] })
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, {}),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "RÉPONSE" }), "Sous 1 à 2 jours ouvrés"] })
									] })
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
						className: "contact-form",
						onSubmit: submit,
						"data-reveal": true,
						children: sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "success-message",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "Demande enregistrée"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Merci. La conversation commence ici." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Votre demande est prête. Dans cette version de démonstration, aucun e-mail n’a été envoyé." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-link",
									onClick: () => setSent(false),
									children: "Modifier ma demande"
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "form-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Votre nom", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									name: "name",
									placeholder: "Comment vous appelez-vous ?"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Votre e-mail", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									type: "email",
									name: "email",
									placeholder: "vous@entreprise.com"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Votre organisation", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								name: "company",
								placeholder: "Nom de votre entreprise ou institution"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", { children: "Sur quoi souhaitez-vous avancer ?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "choice-grid",
								children: options.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: selected.includes(item) ? "is-selected" : "",
									onClick: () => toggle(item),
									children: [selected.includes(item) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {}), item]
								}, item))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Parlez-nous du projet", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								required: true,
								name: "message",
								rows: 6,
								placeholder: "Le contexte, l’objectif, le calendrier… tout ce qui vous semble utile."
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "submit-button",
								type: "submit",
								children: ["Envoyer la demande ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
							})
						] })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "after-contact dark-section",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "section-label light",
							"data-reveal": true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Après votre message" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							"data-reveal": true,
							children: [
								"Simple, humain,",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "sans détour." })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "after-grid",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									"data-reveal": true,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "01" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Nous vous écoutons" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Un échange pour comprendre le contexte, les personnes concernées et le résultat attendu." })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									"data-reveal": true,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "02" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Nous clarifions" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nous reformulons le besoin, les priorités et la meilleure première étape pour avancer." })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									"data-reveal": true,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "03" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Nous proposons un cap" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Vous recevez une approche, un périmètre et un chemin de collaboration lisibles." })
									]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "faq-section light-section",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "faq-title",
						"data-reveal": true,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "Questions fréquentes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { children: [
							"Avant de",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "commencer." })
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "faq-list",
						children: faqs.map(([q, a], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							open: i === 0,
							"data-reveal": true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", { children: [q, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "+" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: a })]
						}, q))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "cta-band",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow light",
							children: "Vous préférez écrire directement ?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							"data-reveal": true,
							children: "hello@keleya.agency"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							className: "button white",
							href: "mailto:hello@keleya.agency",
							children: ["Écrire un e-mail ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
						})
					]
				})
			]
		})
	});
}
//#endregion
export { ContactPage as default };
