import { t as require_jsx_runtime } from "../index.js";
import { PageShell, n as createLucideIcon, t as ArrowUpRight } from "./SiteShell-Cow8zbxb.js";
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ArrowDown = createLucideIcon("arrow-down", [["path", {
	d: "M12 5v14",
	key: "s699le"
}], ["path", {
	d: "m19 12-7 7-7-7",
	key: "1idqje"
}]]);
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ChartNoAxesCombined = createLucideIcon("chart-no-axes-combined", [
	["path", {
		d: "M12 16v5",
		key: "zza2cw"
	}],
	["path", {
		d: "M16 14.639V21",
		key: "1s85h0"
	}],
	["path", {
		d: "M20 10.656V21",
		key: "q45596"
	}],
	["path", {
		d: "m22 3-8.646 8.646a.5.5 0 0 1-.708 0L9.354 8.354a.5.5 0 0 0-.707 0L2 15",
		key: "1fw8x9"
	}],
	["path", {
		d: "M4 18.463V21",
		key: "1otddq"
	}],
	["path", {
		d: "M8 14.656V21",
		key: "1t2idw"
	}]
]);
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Check = createLucideIcon("check", [["path", {
	d: "M20 6 9 17l-5-5",
	key: "1gmf2c"
}]]);
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Layers = createLucideIcon("layers", [
	["path", {
		d: "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",
		key: "zw3jo"
	}],
	["path", {
		d: "M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",
		key: "1wduqc"
	}],
	["path", {
		d: "M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",
		key: "kqbvx6"
	}]
]);
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Smartphone = createLucideIcon("smartphone", [["rect", {
	width: "14",
	height: "20",
	x: "5",
	y: "2",
	rx: "2",
	ry: "2",
	key: "1yt0o3"
}], ["path", {
	d: "M12 18h.01",
	key: "mhygvu"
}]]);
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Workflow = createLucideIcon("workflow", [
	["rect", {
		width: "8",
		height: "8",
		x: "3",
		y: "3",
		rx: "2",
		key: "by2w9f"
	}],
	["path", {
		d: "M7 11v4a2 2 0 0 0 2 2h4",
		key: "xkn7yn"
	}],
	["rect", {
		width: "8",
		height: "8",
		x: "13",
		y: "13",
		rx: "2",
		key: "1cgmvn"
	}]
]);
//#endregion
//#region app/page.tsx
var import_jsx_runtime = require_jsx_runtime();
var expertise = [
	{
		icon: Smartphone,
		tag: "CONCEVOIR",
		title: "Applications web & mobiles",
		text: "Des applications fluides et intuitives qui donnent à vos équipes et à vos clients un outil qu’ils aiment vraiment utiliser."
	},
	{
		icon: Workflow,
		tag: "SIMPLIFIER",
		title: "Digitalisation des opérations",
		text: "Nous transformons les tâches lentes, répétitives ou dispersées en parcours simples, connectés et mesurables."
	},
	{
		icon: Layers,
		tag: "PILOTER",
		title: "Conception & gestion de projet",
		text: "De l’idée à la mise en ligne, nous cadrons les priorités, coordonnons les acteurs et gardons le projet orienté résultats."
	},
	{
		icon: ChartNoAxesCombined,
		tag: "ACCÉLÉRER",
		title: "Data, automatisation & IA",
		text: "Des tableaux de bord, automatisations et usages pertinents de l’IA pour mieux décider et gagner du temps."
	}
];
var phases = [
	[
		"01",
		"Analyse & Cadrage.",
		"Comprendre votre organisation, vos objectifs et les blocages quotidiens pour cibler les opportunités qui comptent vraiment."
	],
	[
		"02",
		"Stratégie & Conception.",
		"Transformer les besoins en un plan clair, priorisé et réaliste, partagé par toutes les parties prenantes."
	],
	[
		"03",
		"Design de l’Expérience.",
		"Dessiner des parcours simples et élégants, testés tôt pour réduire les incertitudes et favoriser l’adoption."
	],
	[
		"04",
		"Création sur Mesure.",
		"Construire une solution rapide, fiable et évolutive, avec des points de contrôle réguliers et des résultats visibles."
	],
	[
		"05",
		"Lancement & Impact.",
		"Déployer sereinement, accompagner vos équipes et mesurer les gains pour améliorer la solution dans la durée."
	]
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		current: "/",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			id: "contenu",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "home-hero",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
							className: "hero-video",
							autoPlay: true,
							muted: true,
							loop: true,
							playsInline: true,
							preload: "metadata",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
								src: "/keleya-hero.mp4",
								type: "video/mp4"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-overlay" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-grid" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "home-hero-content",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "eyebrow light hero-in one",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}), " Digitalisation opérationnelle · Cameroun"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hero-in two",
										children: "Accélérez votre"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
										className: "hero-in three",
										children: "efficacité"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hero-in four",
										children: "avec élégance."
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hero-lower hero-in five",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nous concevons les systèmes digitaux qui libèrent le potentiel de vos équipes et donnent à votre organisation une longueur d’avance." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										className: "button red",
										href: "/contact",
										children: ["Parler de votre projet ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										className: "text-link light",
										href: "#vision",
										children: ["Découvrir Keleya ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {})]
									})] })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hero-stamp",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "KELEYA" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: [
								"DIGITAL",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"OPERATIONS"
							] })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "vision-section light-section",
					id: "vision",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "section-label",
							"data-reveal": true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "01 / Notre vision" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "vision-layout",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								"data-reveal": true,
								children: [
									"Libérer le potentiel des organisations par une digitalisation ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "opérationnelle" }),
									" de leurs systèmes."
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "vision-aside",
								"data-reveal": true,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "La digitalisation de l’Afrique n’est pas seulement une grande opportunité. C’est également une grande responsabilité." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nous créons des outils ancrés dans les réalités du terrain, capables de rayonner partout." })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "value-strip",
							"data-reveal": true,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "01" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Efficacité" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Créer un progrès visible." })
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "02" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Élégance" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Rendre le complexe évident." })
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "03" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Excellence" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Soigner chaque détail utile." })
								] })
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "expertise-section dark-section",
					id: "expertise",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "section-label light",
							"data-reveal": true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "02 / Domaines d’expertise" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "section-intro",
							"data-reveal": true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow light",
								children: "Ce que nous faisons"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { children: [
								"Du besoin métier",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"à l’outil ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "qui change tout." })
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "expertise-grid",
							children: expertise.map((item, i) => {
								const Icon = item.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "expertise-card",
									"data-reveal": true,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "card-top",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["0", i + 1] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: item.tag }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: item.title }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.text }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "card-arrow" })
									]
								}, item.title);
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "process-section",
					id: "process",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "process-title",
						"data-reveal": true,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow light",
								children: "De la clarté à l’impact"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { children: [
								"Une progression",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"sans zone ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "floue." })
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Chaque phase réduit le risque et rapproche votre organisation d’un résultat concret." })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "phase-list",
						children: phases.map(([number, title, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "phase",
							"data-reveal": true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "phase-marker",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: number })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: ["PHASE ", number] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: title }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: text })
							] })]
						}, number))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "precision-section light-section",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "precision-mark",
						"data-reveal": true,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/keleya-mark-black.png",
							alt: ""
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "+ SYS_GEOMETRY / 01" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "precision-copy",
						"data-reveal": true,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Notre signature"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { children: [
								"Précision",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "& Vision" })
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "La précision transforme une idée en système fiable. La vision lui donne une direction. Chez Keleya, les deux avancent ensemble." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), " Des décisions guidées par l’usage"] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), " Une qualité perceptible, du fond à la forme"] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), " Des solutions pensées pour durer"] })
							] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "cta-band",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow light",
							children: "Une idée, un blocage, une ambition ?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							"data-reveal": true,
							children: [
								"Faisons-en votre",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "prochain avantage." })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							className: "button white",
							href: "/contact",
							children: ["Démarrer la conversation ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
						})
					]
				})
			]
		})
	});
}
//#endregion
export { Home as default };
