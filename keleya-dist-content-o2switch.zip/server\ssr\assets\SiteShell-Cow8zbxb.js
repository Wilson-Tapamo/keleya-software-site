import { a as require_react, s as __toESM, t as require_jsx_runtime } from "../index.js";
import { r as mergeClasses, t as Icon } from "./Icon-BnBN3_Ra.js";
//#region node_modules/lucide-react/dist/esm/shared/src/utils/toKebabCase.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
//#endregion
//#region node_modules/lucide-react/dist/esm/shared/src/utils/toCamelCase.mjs
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var toCamelCase = (string) => string.replace(/^([A-Z])|[\s-_]+(\w)/g, (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase());
//#endregion
//#region node_modules/lucide-react/dist/esm/shared/src/utils/toPascalCase.mjs
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var toPascalCase = (string) => {
	const camelCase = toCamelCase(string);
	return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
};
//#endregion
//#region node_modules/lucide-react/dist/esm/createLucideIcon.mjs
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var createLucideIcon = (iconName, iconNode) => {
	const Component = (0, import_react.forwardRef)(({ className, ...props }, ref) => (0, import_react.createElement)(Icon, {
		ref,
		iconNode,
		className: mergeClasses(`lucide-${toKebabCase(toPascalCase(iconName))}`, `lucide-${iconName}`, className),
		...props
	}));
	Component.displayName = toPascalCase(iconName);
	return Component;
};
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ArrowUpRight = createLucideIcon("arrow-up-right", [["path", {
	d: "M7 7h10v10",
	key: "1tivn9"
}], ["path", {
	d: "M7 17 17 7",
	key: "1vkiza"
}]]);
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Menu = createLucideIcon("menu", [
	["path", {
		d: "M4 5h16",
		key: "1tepv9"
	}],
	["path", {
		d: "M4 12h16",
		key: "1lakjw"
	}],
	["path", {
		d: "M4 19h16",
		key: "1djgab"
	}]
]);
/**
* @license lucide-react v1.27.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var X = createLucideIcon("x", [["path", {
	d: "M18 6 6 18",
	key: "1bl5f8"
}], ["path", {
	d: "m6 6 12 12",
	key: "d8bk6v"
}]]);
//#endregion
//#region app/components/SiteShell.tsx
var import_jsx_runtime = require_jsx_runtime();
var links = [
	["Accueil", "/"],
	["Services", "/services"],
	["À propos", "/a-propos"],
	["Contact", "/contact"]
];
function Brand() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		className: "brand",
		href: "/",
		"aria-label": "Keleya — Accueil",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/keleya-mark-red.png",
			alt: "",
			width: "84",
			height: "84"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Keleya" })]
	});
}
function Header({ current }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: `site-header ${scrolled ? "is-scrolled" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: open ? "site-nav is-open" : "site-nav",
				"aria-label": "Navigation principale",
				children: links.map(([label, href]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: current === href ? "is-active" : "",
					href,
					onClick: () => setOpen(false),
					children: label
				}, href))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				className: "header-cta",
				href: "/contact",
				children: ["Démarrer un projet ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "menu-button",
				onClick: () => setOpen(!open),
				"aria-label": open ? "Fermer le menu" : "Ouvrir le menu",
				"aria-expanded": open,
				children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "header-signal" })
		]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "site-footer",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "footer-lead",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow light",
						children: "Votre prochain avantage commence ici"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { children: [
						"Bâtissons",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "votre élan." })
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "circle-link",
						href: "/contact",
						"aria-label": "Lancer un projet",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "footer-meta",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "ÉCRIVEZ-NOUS" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "mailto:hello@keleya.agency",
						children: "hello@keleya.agency"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "RETROUVEZ-NOUS" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#",
							children: "LinkedIn"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#",
							children: "Instagram"
						})
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "footer-bottom",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "© 2026 Keleya. Tous droits réservés." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Yaoundé, Cameroun — Pour l’Afrique et le monde." })]
			})
		]
	});
}
function RevealObserver() {
	(0, import_react.useEffect)(() => {
		const nodes = document.querySelectorAll("[data-reveal]");
		const observer = new IntersectionObserver((entries) => {
			entries.forEach((entry) => entry.isIntersecting && entry.target.classList.add("is-visible"));
		}, {
			threshold: .12,
			rootMargin: "0px 0px -8%"
		});
		nodes.forEach((node) => observer.observe(node));
		return () => observer.disconnect();
	}, []);
	return null;
}
function PageShell({ current, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: "skip-link",
			href: "#contenu",
			children: "Aller au contenu"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, { current }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RevealObserver, {}),
		children,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
	] });
}
function PageHero({ index, kicker, title, accent, copy }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "page-hero",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "page-hero-grid" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "page-hero-top",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: index }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: kicker })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: accent })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: copy }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "scroll-cue",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Défiler" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})]
			})
		]
	});
}
//#endregion
export { PageHero, PageShell, createLucideIcon as n, ArrowUpRight as t };
